Weather report only works in Windows.

Weather report requires internet connection to run.

This program was created by levi santegoets on 18-05-2024.

The program is obfuscated but on request you can recieve the source code.